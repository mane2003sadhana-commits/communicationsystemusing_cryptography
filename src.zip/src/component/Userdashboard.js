import React, { useState } from "react";
import CryptographyLab from "./CryptographyLab";
import Inbox from "./Inbox";

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState("crypto");

  const renderContent = () => {
    switch (activeTab) {
      case "crypto":
        return (
          <>
            <h2>Cryptography Lab</h2>
            <CryptographyLab />
          </>
        );
      case "tutorials":
        return (
          <>
            <h2>Tutorials</h2>
            <p>
              Learn cryptography concepts with explanations, examples, and
              “Try It Yourself” demos.
            </p>
          </>
        );
      case "inbox":
        return (
          <>
            <h2>Inbox</h2>
            <Inbox />
          </>
        );
      case "profile":
        return (
          <>
            <h2>Profile</h2>
            <p>View your user details and cryptography activity summary.</p>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div style={styles.container}>
      {/* HEADER */}
      <div style={styles.header}>Secure Communication System</div>

      {/* NAVBAR */}
      <div style={styles.navbar}>
        <button onClick={() => setActiveTab("crypto")} style={styles.navBtn}>
          Cryptography Lab
        </button>
        <button onClick={() => setActiveTab("tutorials")} style={styles.navBtn}>
          Tutorials
        </button>
        <button onClick={() => setActiveTab("inbox")} style={styles.navBtn}>
          Inbox
        </button>
        <button onClick={() => setActiveTab("profile")} style={styles.navBtn}>
          Profile
        </button>
      </div>

      {/* MAIN CONTENT */}
      <div style={styles.mainContent}>{renderContent()}</div>
    </div>
  );
};

export default UserDashboard;

/* ===== STYLES ===== */
const styles = {
  container: {
    height: "100vh",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f4f6f8",
  },
  header: {
    backgroundColor: "#1e293b",
    color: "#ffffff",
    padding: "18px",
    fontSize: "20px",
    fontWeight: "bold",
    textAlign: "center",
  },
  navbar: {
    display: "flex",
    justifyContent: "center",
    gap: "15px",
    padding: "12px",
    backgroundColor: "#e5e7eb",
  },
  navBtn: {
    padding: "8px 16px",
    border: "none",
    backgroundColor: "#2563eb",
    color: "#ffffff",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "14px",
  },
  mainContent: {
    margin: "20px auto",
    padding: "25px",
    width: "80%",
    minHeight: "60vh",
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    boxShadow: "0 10px 20px rgba(0,0,0,0.1)",
  },
};
