import React, { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { rtdb, auth } from "../Firebaseconfig";

const Inbox = () => {
  const [messages, setMessages] = useState([]);
  const [usersMap, setUsersMap] = useState({});
  const [decryptedMap, setDecryptedMap] = useState({});
  const [openMsgId, setOpenMsgId] = useState(null); // track opened message

  // Fetch all users
  useEffect(() => {
    const usersRef = ref(rtdb, "users");
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val() || {};
      const map = {};
      Object.entries(data).forEach(([uid, user]) => {
        map[uid] = user.fullname || user.name || "Unknown";
      });
      setUsersMap(map);
    });
    return () => unsubscribe();
  }, []);

  // Fetch messages for current user
  useEffect(() => {
    if (!auth.currentUser) return;

    const messagesRef = ref(rtdb, "messages");
    const unsubscribe = onValue(messagesRef, (snapshot) => {
      const data = snapshot.val() || {};
      const inbox = Object.entries(data)
        .filter(([id, msg]) => msg.receiverId === auth.currentUser.uid)
        .map(([id, msg]) => ({ id, ...msg }))
        .sort((a, b) => b.timestamp - a.timestamp);

      setMessages(inbox);
    });

    return () => unsubscribe();
  }, []);

  // Caesar Cipher decrypt
  const caesarDecrypt = (text, shift) => {
    return text
      .toUpperCase()
      .split("")
      .map((char) => {
        if (char < "A" || char > "Z") return char;
        return String.fromCharCode(((char.charCodeAt(0) - 65 - shift + 26) % 26) + 65);
      })
      .join("");
  };

  const handleDecrypt = (msg) => {
    if (msg.method === "caesar") {
      const decrypted = caesarDecrypt(msg.encryptedMsg, parseInt(msg.key));
      setDecryptedMap((prev) => ({ ...prev, [msg.id]: decrypted }));
    } else {
      setDecryptedMap((prev) => ({
        ...prev,
        [msg.id]: `Decrypt not implemented for ${msg.method}`,
      }));
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Inbox</h2>
      {messages.length === 0 ? (
        <p style={styles.noMsg}>No messages found.</p>
      ) : (
        <div style={styles.msgList}>
          {messages.map((msg) => {
            const isOpen = openMsgId === msg.id;
            return (
              <div key={msg.id} style={styles.card}>
                {/* Header: From, Time, View Button */}
                <div style={styles.header}>
                  <span style={styles.sender}>{usersMap[msg.senderId] || "Unknown"}</span>
                  <span style={styles.time}>{new Date(msg.timestamp).toLocaleString()}</span>
                  <button
                    style={styles.viewBtn}
                    onClick={() => setOpenMsgId(isOpen ? null : msg.id)}
                  >
                    {isOpen ? "Hide" : "View"}
                  </button>
                </div>

                {/* Expanded Content */}
                {isOpen && (
                  <div style={styles.content}>
                    <p><b>Encrypted:</b> {msg.encryptedMsg}</p>
                    <p><b>Key:</b> {msg.key}</p>
                    <p><b>Method:</b> {msg.method}</p>
                    <button style={styles.decryptBtn} onClick={() => handleDecrypt(msg)}>
                      Decrypt
                    </button>
                    {decryptedMap[msg.id] && (
                      <div style={styles.decrypted}>
                        <b>Decrypted:</b> {decryptedMap[msg.id]}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Inbox;

// -----------------------------
// Styles
// -----------------------------
const styles = {
  container: {
    width: "100%",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
    color: "#1e293b",
  },
  noMsg: {
    textAlign: "center",
    fontStyle: "italic",
    color: "#555",
  },
  msgList: {
    display: "flex",
    flexDirection: "column",
    gap: "15px",
    maxHeight: "60vh",
    overflowY: "auto",
    paddingRight: "5px",
  },
  card: {
    backgroundColor: "#f9fafb",
    padding: "12px 15px",
    borderRadius: "10px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    transition: "transform 0.2s, box-shadow 0.2s",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "5px",
  },
  sender: {
    fontWeight: "bold",
    color: "#2563eb",
  },
  time: {
    fontSize: "12px",
    color: "#555",
    marginRight: "10px",
  },
  viewBtn: {
    padding: "5px 12px",
    backgroundColor: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "12px",
  },
  content: {
    marginTop: "10px",
    fontSize: "14px",
    color: "#1f2937",
  },
  decryptBtn: {
    padding: "6px 12px",
    backgroundColor: "#16a34a",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "bold",
    marginTop: "10px",
  },
  decrypted: {
    padding: "10px",
    backgroundColor: "#e0f2fe",
    borderRadius: "6px",
    fontWeight: "bold",
    color: "#0c4a6e",
    marginTop: "10px",
  },
};
