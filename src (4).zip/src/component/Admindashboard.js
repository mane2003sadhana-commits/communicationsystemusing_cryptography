import React, { useEffect, useState } from "react";
import { ref, onValue } from "firebase/database";
import { rtdb, auth } from "../Firebaseconfig";
import { signOut } from "firebase/auth";

const Admindashboard = () => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedReport, setSelectedReport] = useState("users");

  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);

  const [selectedUser, setSelectedUser] = useState("");
  const [selectedMethod, setSelectedMethod] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  // FETCH USERS
  useEffect(() => {
    const userRef = ref(rtdb, "users");
    onValue(userRef, (snap) => {
      const data = snap.val() || {};
      const list = Object.entries(data).map(([id, val]) => ({
        id,
        ...val,
      }));
      setUsers(list);
    });
  }, []);

  // FETCH MESSAGES
  useEffect(() => {
    const msgRef = ref(rtdb, "messages");
    onValue(msgRef, (snap) => {
      const data = snap.val() || {};
      const list = Object.values(data);
      setMessages(list);
    });
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    window.location.href = "/";
  };

  const formatDate = (ts) =>
    new Date(ts).toLocaleDateString();

  const getUserName = (id) => {
    const u = users.find((x) => x.id === id);
    return u?.fullname || u?.name || "Unknown";
  };

  // FILTER
  const filteredMessages = messages.filter((m) => {
    return (
      (!selectedUser || m.senderId === selectedUser) &&
      (!selectedMethod || m.method === selectedMethod) &&
      (!fromDate || m.timestamp >= new Date(fromDate).getTime()) &&
      (!toDate || m.timestamp <= new Date(toDate).getTime())
    );
  });

  // ---------------- REPORTS ----------------

  const renderUserReport = () => (
    <div style={styles.card}>
      <h3>👥 User Report</h3>
      <table style={styles.table}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, i) => (
            <tr key={i}>
              <td>{u.name || u.fullname}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderMessageReport = () => (
    <div style={styles.card}>
      <h3>💬 Message Report</h3>

      {/* FILTERS */}
      <div style={styles.filterBox}>
        <select onChange={(e) => setSelectedUser(e.target.value)}>
          <option value="">All Users</option>
          {users.map((u) => (
            <option key={u.id} value={u.id}>
              {u.name || u.fullname}
            </option>
          ))}
        </select>

        <select onChange={(e) => setSelectedMethod(e.target.value)}>
          <option value="">All Methods</option>
          <option value="caesar">Caesar</option>
          <option value="vigenere">Vigenere</option>
          <option value="railfence">RailFence</option>
          <option value="columnar">Columnar</option>
        </select>

        <input type="date" onChange={(e) => setFromDate(e.target.value)} />
        <input type="date" onChange={(e) => setToDate(e.target.value)} />
      </div>

      <table style={styles.table}>
        <thead>
          <tr>
            <th>Sender</th>
            <th>Receiver</th>
            <th>Method</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {filteredMessages.map((m, i) => (
            <tr key={i}>
              <td>{getUserName(m.senderId)}</td>
              <td>{getUserName(m.receiverId)}</td>
              <td>{m.method}</td>
              <td>{formatDate(m.timestamp)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderEncryptionReport = () => {
    const count = {};
    messages.forEach((m) => {
      count[m.method] = (count[m.method] || 0) + 1;
    });

    return (
      <div style={styles.card}>
        <h3>🔐 Encryption Report</h3>
        <table style={styles.table}>
          <thead>
            <tr>
              <th>Method</th>
              <th>Count</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(count).map(([k, v], i) => (
              <tr key={i}>
                <td>{k}</td>
                <td>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderActivityReport = () => {
    const daily = {};
    messages.forEach((m) => {
      const d = formatDate(m.timestamp);
      daily[d] = (daily[d] || 0) + 1;
    });

    return (
      <div style={styles.card}>
        <h3>📈 Activity Report</h3>
        <table style={styles.table}>
          <thead>
            <tr>
              <th>Date</th>
              <th>Messages</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(daily).map(([d, v], i) => (
              <tr key={i}>
                <td>{d}</td>
                <td>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderTopUsers = () => {
    const count = {};
    messages.forEach((m) => {
      count[m.senderId] = (count[m.senderId] || 0) + 1;
    });

    return (
      <div style={styles.card}>
        <h3>🏆 Top Users</h3>
        <table style={styles.table}>
          <thead>
            <tr>
              <th>User</th>
              <th>Messages</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(count).map(([id, v], i) => (
              <tr key={i}>
                <td>{getUserName(id)}</td>
                <td>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderReport = () => {
    if (selectedReport === "users") return renderUserReport();
    if (selectedReport === "messages") return renderMessageReport();
    if (selectedReport === "encryption") return renderEncryptionReport();
    if (selectedReport === "activity") return renderActivityReport();
    if (selectedReport === "top") return renderTopUsers();
  };

  return (
    <div style={styles.container}>
      {/* SIDEBAR */}
      <div style={styles.sidebar}>
        <h2 style={styles.logo}>Admin</h2>

        <button
          style={activeTab === "dashboard" ? styles.active : styles.menu}
          onClick={() => setActiveTab("dashboard")}
        >
          Dashboard
        </button>

        <button
          style={activeTab === "reports" ? styles.active : styles.menu}
          onClick={() => setActiveTab("reports")}
        >
          Reports ▼
        </button>

        {activeTab === "reports" && (
          <div style={styles.subMenu}>
            <button onClick={() => setSelectedReport("users")}>User Report</button>
            <button onClick={() => setSelectedReport("messages")}>Message Report</button>
            <button onClick={() => setSelectedReport("encryption")}>Encryption</button>
            <button onClick={() => setSelectedReport("activity")}>Activity</button>
            <button onClick={() => setSelectedReport("top")}>Top Users</button>
          </div>
        )}

        <button style={styles.logout} onClick={handleLogout}>
          Logout
        </button>
      </div>

      {/* MAIN */}
      <div style={styles.main}>
        {activeTab === "dashboard" && (
          <div style={styles.card}>
            <h2>📊 Dashboard (You can add charts here)</h2>
          </div>
        )}

        {activeTab === "reports" && renderReport()}
      </div>
    </div>
  );
};

export default Admindashboard;

// 🎨 STYLES
const styles = {
  container: { display: "flex", minHeight: "100vh", background: "#f1f5f9" },

  sidebar: {
    width: "250px",
    background: "linear-gradient(180deg,#2563eb,#1e40af)",
    color: "white",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
  },

  logo: { textAlign: "center", marginBottom: "20px" },

  menu: {
    padding: "12px",
    marginBottom: "10px",
    background: "rgba(255,255,255,0.2)",
    border: "none",
    borderRadius: "8px",
    color: "white",
    cursor: "pointer",
  },

  active: {
    padding: "12px",
    marginBottom: "10px",
    background: "white",
    color: "#2563eb",
    borderRadius: "8px",
    fontWeight: "bold",
  },

  subMenu: {
    marginLeft: "10px",
    display: "flex",
    flexDirection: "column",
    gap: "5px",
  },

  logout: {
    marginTop: "auto",
    padding: "12px",
    background: "#ef4444",
    color: "white",
    border: "none",
    borderRadius: "8px",
  },

  main: { flex: 1, padding: "20px" },

  card: {
    background: "white",
    padding: "20px",
    borderRadius: "12px",
    boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
  },

  table: {
    width: "100%",
    marginTop: "15px",
    borderCollapse: "collapse",
  },

  filterBox: {
    display: "flex",
    gap: "10px",
    marginBottom: "10px",
  },
};