import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const VigenereCipher = () => {
  const [text, setText] = useState("");
  const [key, setKey] = useState("");
  const [result, setResult] = useState("");
  const navigate = useNavigate();

  // Helper: Repeat key to match text length
  const generateKey = (text, key) => {
    key = key.toUpperCase().replace(/[^A-Z]/g, "");
    if (!key) return "";

    let newKey = "";
    let j = 0;

    for (let i = 0; i < text.length; i++) {
      if (text[i] >= "A" && text[i] <= "Z") {
        newKey += key[j % key.length];
        j++;
      } else {
        newKey += text[i];
      }
    }
    return newKey;
  };

  const encrypt = () => {
    let upperText = text.toUpperCase();
    let newKey = generateKey(upperText, key);
    let output = "";

    for (let i = 0; i < upperText.length; i++) {
      let t = upperText[i];
      let k = newKey[i];

      if (t < "A" || t > "Z") {
        output += t;
      } else {
        let encryptedChar = String.fromCharCode(
          ((t.charCodeAt(0) - 65 + (k.charCodeAt(0) - 65)) % 26) + 65
        );
        output += encryptedChar;
      }
    }

    setResult(output);
  };

  const decrypt = () => {
    let upperText = text.toUpperCase();
    let newKey = generateKey(upperText, key);
    let output = "";

    for (let i = 0; i < upperText.length; i++) {
      let t = upperText[i];
      let k = newKey[i];

      if (t < "A" || t > "Z") {
        output += t;
      } else {
        let decryptedChar = String.fromCharCode(
          ((t.charCodeAt(0) - 65 - (k.charCodeAt(0) - 65) + 26) % 26) + 65
        );
        output += decryptedChar;
      }
    }

    setResult(output);
  };

  return (
    <div style={styles.page}>
      <div style={styles.overlay}>
        <div style={styles.card}>

          {/* BACK BUTTON */}
          <button style={styles.backBtn} onClick={() => navigate(-1)}>
            ← Back
          </button>

          <h2 style={styles.title}>🔐 Vigenère Cipher Tool</h2>

          <h4 style={styles.heading}>Introduction</h4>
          <p style={styles.text}>
            Vigenère Cipher is a polyalphabetic substitution cipher. It uses a
            keyword to apply multiple Caesar shifts on the message.
          </p>

          <h4 style={styles.heading}>Example</h4>
          <p style={styles.text}>
            Message: <b>HELLO</b> <br />
            Key: <b>KEY</b> <br />
            Encrypted: <b>RIJVS</b>
          </p>

          <h4 style={styles.heading}>Try It Yourself</h4>

          <textarea
            style={styles.input}
            placeholder="Enter your message..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />

          <input
            type="text"
            style={styles.input}
            placeholder="Enter secret key..."
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />

          <div style={styles.btnContainer}>
            <button style={styles.encryptBtn} onClick={encrypt}>
              Encrypt
            </button>

            <button style={styles.decryptBtn} onClick={decrypt}>
              Decrypt
            </button>
          </div>

          {result && (
            <div style={styles.resultBox}>
              <p><b>Output:</b></p>
              <p style={styles.resultText}>{result}</p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default VigenereCipher;

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundImage:
      "url('https://images.unsplash.com/photo-1526378722484-cc5c510c9c4b?auto=format&fit=crop&w=1600&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },

  overlay: {
    width: "100%",
    height: "100%",
    background: "rgba(0,0,0,0.6)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  card: {
    position: "relative",   // IMPORTANT for back button
    width: "100%",
    maxWidth: "500px",
    background: "rgba(255,255,255,0.1)",
    backdropFilter: "blur(18px)",
    borderRadius: "18px",
    padding: "25px",
    color: "#fff",
    boxShadow: "0 15px 40px rgba(0,0,0,0.4)",
  },

  backBtn: {
    position: "absolute",
    top: "15px",
    left: "15px",
    padding: "6px 12px",
    background: "rgba(255,255,255,0.2)",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontSize: "13px",
    backdropFilter: "blur(8px)",
  },

  title: {
    textAlign: "center",
    marginBottom: "15px",
    fontSize: "26px",
    fontWeight: "bold",
  },

  heading: {
    marginTop: "15px",
    color: "#c7d2fe",
  },

  text: {
    fontSize: "14px",
    lineHeight: "1.6",
  },

  input: {
    width: "90%",
    marginTop: "10px",
    padding: "12px",
    borderRadius: "10px",
    border: "none",
    outline: "none",
    fontSize: "14px",
    display: "block",
    marginLeft: "auto",
    marginRight: "auto",
  },

  btnContainer: {
    display: "flex",
    justifyContent: "center",
    gap: "15px",
    marginTop: "18px",
  },

  encryptBtn: {
    padding: "10px 18px",
    background: "linear-gradient(135deg, #22c55e, #16a34a)",
    color: "#fff",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    fontWeight: "bold",
  },

  decryptBtn: {
    padding: "10px 18px",
    background: "linear-gradient(135deg, #ef4444, #dc2626)",
    color: "#fff",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    fontWeight: "bold",
  },

  resultBox: {
    marginTop: "20px",
    padding: "15px",
    background: "rgba(255,255,255,0.15)",
    borderRadius: "12px",
    textAlign: "center",
  },

  resultText: {
    marginTop: "5px",
    fontWeight: "bold",
    color: "#facc15",
    fontSize: "16px",
  },
};