import React, { useState } from "react";

const CaesarCipher = () => {
  const [text, setText] = useState("");
  const [key, setKey] = useState(3);
  const [result, setResult] = useState("");

  const encrypt = () => {
    const encrypted = text
      .toUpperCase()
      .split("")
      .map((c) => {
        if (c < "A" || c > "Z") return c;
        return String.fromCharCode(
          ((c.charCodeAt(0) - 65 + Number(key)) % 26) + 65
        );
      })
      .join("");

    setResult(encrypted);
  };

  const decrypt = () => {
    const decrypted = text
      .toUpperCase()
      .split("")
      .map((c) => {
        if (c < "A" || c > "Z") return c;
        return String.fromCharCode(
          ((c.charCodeAt(0) - 65 - Number(key) + 26) % 26) + 65
        );
      })
      .join("");

    setResult(decrypted);
  };

  return (
    <div style={styles.page}>
      <div style={styles.overlay}></div>

      <div style={styles.card}>
        <h2 style={styles.title}>🔐 Caesar Cipher Tool</h2>

        <h4 style={styles.subheading}>Introduction</h4>
        <p style={styles.text}>
          Caesar Cipher is one of the simplest and oldest encryption techniques.
          Each letter is shifted by a fixed number of positions.
        </p>

        <h4 style={styles.subheading}>Example</h4>
        <p style={styles.text}>
          Message: <b>HELLO</b><br />
          Key: <b>3</b><br />
          Encrypted: <b>KHOOR</b>
        </p>

        <h4 style={styles.subheading}>Try It Yourself</h4>

        <textarea
          style={styles.input}
          placeholder="Enter message..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />

        <input
          type="number"
          style={styles.input}
          value={key}
          onChange={(e) => setKey(e.target.value)}
        />

        <div style={styles.buttonGroup}>
          <button style={styles.btn} onClick={encrypt}>
            🔒 Encrypt
          </button>
          <button style={styles.btnSecondary} onClick={decrypt}>
            🔓 Decrypt
          </button>
        </div>

        {result && (
          <div style={styles.outputBox}>
            <span style={styles.outputLabel}>Result</span>
            <p style={styles.outputText}>{result}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CaesarCipher;

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundImage:
      "url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    position: "relative",
    fontFamily: "Poppins, sans-serif",
  },

  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background: "rgba(0,0,0,0.6)",
    zIndex: 0,
  },

  card: {
    width: "420px",
    padding: "30px",
    borderRadius: "15px",
    background: "rgba(255, 255, 255, 0.15)",
    backdropFilter: "blur(12px)",
    border: "1px solid rgba(255,255,255,0.2)",
    boxShadow: "0 15px 35px rgba(34, 26, 26, 0.4)",
    color: "#fff",
    position: "relative",
    zIndex: 1,
  },

  title: {
    textAlign: "center",
    marginBottom: "15px",
  },

  subheading: {
    marginTop: "15px",
    marginBottom: "5px",
    fontSize: "14px",
    opacity: 0.9,
  },

  text: {
    fontSize: "13px",
    opacity: 0.85,
  },

  input: {
    width: "100%",
    marginTop: "10px",
    padding: "12px",
    borderRadius: "8px",
    border: "none",
    outline: "none",
    fontSize: "14px",
  },

  buttonGroup: {
    marginTop: "15px",
    display: "flex",
    gap: "10px",
  },

  btn: {
    flex: 1,
    padding: "10px",
    background: "linear-gradient(135deg, #3b82f6, #6366f1)",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },

  btnSecondary: {
    flex: 1,
    padding: "10px",
    background: "linear-gradient(135deg, #10b981, #22c55e)",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    fontWeight: "bold",
  },

  outputBox: {
    marginTop: "20px",
    padding: "15px",
    borderRadius: "10px",
    background: "rgba(31, 28, 28, 0.5)",
  },

  outputLabel: {
    fontSize: "12px",
    opacity: 0.7,
  },

  outputText: {
    marginTop: "5px",
    fontWeight: "bold",
    letterSpacing: "1px",
  },
};